
import React from 'react';
import AssetIcon from './AssetIcon';

interface IconProps {
  className?: string;
  size?: number;
}

const ImageIcon: React.FC<{name:any; className?: string; rotate?: number; size?: number}> = ({ name, className = 'w-5 h-5', rotate = 0, size }) => (
  <span className={`inline-flex items-center justify-center ${className}`} style={{ transform: rotate ? `rotate(${rotate}deg)` : undefined, width: size, height: size }}>
    <AssetIcon name={name} className="w-full h-full" />
  </span>
);

const starName = (className='') => /fill-|text-(yellow|amber|orange)/.test(className) ? 'star' : 'starOutline';
const heartName = (className='') => /(fill-|text-red|text-pink)/.test(className) ? 'heart' : 'heartOutline';

export const Home: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="home" className={className} size={size} />;
export const HelpCircle: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="question" className={className} size={size} />;
export const Star: React.FC<IconProps> = ({ className, size }) => <ImageIcon name={starName(className)} className={className} size={size} />;
export const Timer: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="timer" className={className} size={size} />;
export const Target: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="medal" className={className} size={size} />;
export const Check: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="check" className={className} size={size} />;
export const X: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="x" className={className} size={size} />;
export const Key: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="coin" className={className} size={size} />;
export const Lock: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="x" className={className} size={size} />;
export const Unlock: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="check" className={className} size={size} />;
export const Flame: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="gem" className={className} size={size} />;
export const Hammer: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="medal" className={className} size={size} />;
export const Coins: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="coin" className={className} size={size} />;
export const Store: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="doc" className={className} size={size} />;
export const RotateCcw: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="refresh" className={className} size={size} />;
export const CheckCircle2: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="check" className={className} size={size} />;
export const FlaskConical: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="gem" className={className} size={size} />;
export const Beaker: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="gem" className={className} size={size} />;
export const Droplets: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="gem" className={className} size={size} />;
export const Crosshair: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="plus" className={className} size={size} />;
export const Anchor: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="medal" className={className} size={size} />;
export const Bomb: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="x" className={className} size={size} />;
export const ArrowRightLeft: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="refresh" className={className} size={size} />;
export const ArrowUpDown: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="refresh" className={className} rotate={90} size={size} />;
export const Clock: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="stopwatch" className={className} size={size} />;
export const Hourglass: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="timer" className={className} size={size} />;
export const Castle: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="home" className={className} size={size} />;
export const ChevronRight: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="play" className={className} size={size} />;
export const ChevronLeft: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="back" className={className} size={size} />;
export const Trophy: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="trophy" className={className} size={size} />;
export const RefreshCw: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="refresh" className={className} size={size} />;
export const XCircle: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="x" className={className} size={size} />;
export const Lightbulb: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="info" className={className} size={size} />;
export const ArrowLeft: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="back" className={className} size={size} />;
export const ArrowRight: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="play" className={className} size={size} />;
export const Heart: React.FC<IconProps> = ({ className, size }) => <ImageIcon name={heartName(className)} className={className} size={size} />;
export const RotateCw: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="refresh" className={className} rotate={180} size={size} />;
export const FlipHorizontal: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="refresh" className={className} rotate={45} size={size} />;
export const Sparkles: React.FC<IconProps> = ({ className, size }) => <ImageIcon name="gem" className={className} size={size} />;
