import React from 'react';
import { Home, HelpCircle } from 'lucide-react';

interface GameActionDockProps {
  onBack: () => void;
  onHelp?: () => void;
  accentClass?: string;
}

const GameActionDock: React.FC<GameActionDockProps> = ({ onBack, onHelp, accentClass = 'text-slate-700' }) => {
  return (
    <div className="flex items-center gap-3 md:gap-4 mt-2 md:mt-4">
      <button
        onClick={onBack}
        className={`game-dock-button ${accentClass}`}
        aria-label="Back to island"
      >
        <Home className="w-5 h-5 md:w-6 md:h-6" />
      </button>
      <button
        onClick={onHelp}
        className={`game-dock-button ${accentClass}`}
        aria-label="Open help"
      >
        <HelpCircle className="w-5 h-5 md:w-6 md:h-6" />
      </button>
    </div>
  );
};

export default GameActionDock;
