import React from 'react';
import { motion } from 'motion/react';
import { IslandData, PlayerData, LevelData } from '../types';
import { ArrowLeft, Star, Lock, Play } from 'lucide-react';

interface IslandLevelsProps {
  island: IslandData;
  player: PlayerData;
  onBack: () => void;
  onSelectLevel: (level: LevelData) => void;
}

const IslandLevels: React.FC<IslandLevelsProps> = ({ island, player, onBack, onSelectLevel }) => {
  const completedLevels = player.completedLevels[island.id] || [];

  return (
    <div className={`relative w-full h-full flex flex-col items-center p-4 md:p-8 overflow-y-auto min-h-0 bg-gradient-to-b ${island.bgGradient || 'from-sky-400 to-sky-200'} font-sans`}>
      
      {/* Decorations Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {island.decorations?.map((dec, i) => (
          <motion.div
            key={i}
            animate={{ 
              y: [0, -20, 0],
              rotate: [0, 5, -5, 0]
            }}
            transition={{ 
              duration: 6 + i, 
              repeat: Infinity, 
              ease: "easeInOut",
              delay: i * 0.5
            }}
            className="absolute text-6xl md:text-8xl opacity-30 filter blur-[1px] drop-shadow-xl"
            style={{
              top: `${10 + (i * 25)}%`,
              left: `${5 + (i * 30)}%`,
              transform: `scale(${1 + (i * 0.2)})`
            }}
          >
            {dec}
          </motion.div>
        ))}
      </div>
      
      <header className="w-full max-w-4xl flex justify-between items-start mb-8 md:mb-16 relative z-10 mt-4">
        <div className="flex items-center gap-4">
          <motion.button 
            whileHover={{ scale: 1.1, x: -5 }}
            whileTap={{ scale: 0.9 }}
            onClick={onBack}
            className="bg-white/10 backdrop-blur-xl p-4 md:p-5 rounded-[2rem] text-white hover:bg-white/20 transition-all shadow-xl border border-white/20"
          >
            <ArrowLeft className="w-8 h-8 md:w-10 md:h-10" />
          </motion.button>
          
          <div className="hidden md:flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <span className="text-white font-black text-xl">{player.playerName}</span>
              <span className="bg-yellow-400 text-yellow-950 px-2 py-0.5 rounded-lg text-[10px] font-black">LVL {player.level}</span>
            </div>
            <div className="w-32 h-2 bg-black/40 rounded-full overflow-hidden border border-white/10">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${(player.xp % 1000) / 10}%` }}
                className="h-full bg-gradient-to-r from-blue-400 to-purple-500"
              />
            </div>
          </div>
        </div>

        <div className="text-center flex flex-col items-center">
          <div className="bg-black/40 backdrop-blur-md px-6 py-2 rounded-full text-white/90 font-black uppercase tracking-[0.4em] text-xs md:text-sm mb-3 border border-white/20 shadow-lg inline-block">
            {island.category}
          </div>
          <motion.h1 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="text-4xl md:text-7xl font-black text-white drop-shadow-[0_6px_0_rgba(0,0,0,0.3)] tracking-tighter"
          >
            {island.themeName || island.name}
          </motion.h1>
        </div>

        <div className="flex gap-2">
          <div className="bg-white/10 backdrop-blur-xl px-4 py-2 rounded-2xl text-white font-black shadow-lg border border-white/20 flex items-center gap-2 text-sm md:text-base">
            <span className="text-yellow-400">💰</span>
            {player.coins}
          </div>
          <div className="bg-white/10 backdrop-blur-xl px-4 py-2 rounded-2xl text-white font-black shadow-lg border border-white/20 flex items-center gap-2 text-sm md:text-base">
            <span className="text-blue-400">💎</span>
            {player.gems}
          </div>
        </div>
      </header>

      <div className="w-full max-w-3xl flex flex-col gap-6 md:gap-8 relative z-10 pb-32">
        {island.levels.map((level, index) => {
          const isUnlocked = true; // Force unlocked for testing
          const stars = level.stars || 0;

          return (
            <motion.button
              key={level.id}
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.08, type: 'spring', stiffness: 100 }}
              whileHover={isUnlocked ? { scale: 1.02, x: 10 } : {}}
              whileTap={isUnlocked ? { scale: 0.98 } : {}}
              onClick={() => isUnlocked && onSelectLevel(level)}
              disabled={!isUnlocked}
              className={`
                relative w-full p-5 md:p-8 rounded-[2.5rem] md:rounded-[3rem] border-b-[8px] md:border-b-[12px] flex items-center justify-between transition-all group overflow-hidden
                ${isUnlocked 
                  ? 'bg-white/20 backdrop-blur-xl border-white/40 hover:bg-white/30 shadow-[0_20px_40px_rgba(0,0,0,0.2)]' 
                  : 'bg-black/20 border-black/40 opacity-70 cursor-not-allowed backdrop-blur-md'
                }
              `}
            >
              {/* Card Gloss */}
              {isUnlocked && (
                <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />
              )}

              <div className="flex items-center gap-6 md:gap-8 relative z-10">
                <div className={`
                  w-16 h-16 md:w-24 md:h-24 rounded-[1.5rem] md:rounded-[2rem] flex items-center justify-center text-3xl md:text-5xl font-black border-b-[6px] md:border-b-[8px] transition-transform group-hover:scale-110 shadow-xl
                  ${isUnlocked ? 'bg-white text-gray-800 border-gray-300' : 'bg-gray-500 text-gray-700 border-gray-600'}
                `}>
                  {level.id}
                </div>
                
                <div className="text-left">
                  <h3 className={`text-2xl md:text-4xl font-black tracking-tight mb-2 ${isUnlocked ? 'text-white drop-shadow-[0_2px_2px_rgba(0,0,0,0.5)]' : 'text-white/40'}`}>
                    {level.isBoss ? 'BOSS CHALLENGE' : `Stage ${level.id}`}
                  </h3>
                  <div className="flex gap-2 md:gap-3">
                    {[1, 2, 3].map(s => (
                      <motion.div
                        key={s}
                        animate={s <= stars ? { scale: [1, 1.2, 1] } : {}}
                        transition={{ delay: s * 0.1 }}
                      >
                        <Star 
                          className={`w-6 h-6 md:w-8 md:h-8 ${s <= stars ? 'fill-yellow-400 text-yellow-400 filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)]' : 'text-white/30 fill-black/20'}`} 
                        />
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-6 md:gap-8 relative z-10">
                <div className="text-right hidden sm:block bg-black/20 px-4 py-2 rounded-2xl backdrop-blur-sm border border-white/10">
                  <div className="text-[10px] md:text-xs font-black text-white/70 uppercase tracking-widest mb-1">Mode</div>
                  <div className="text-sm md:text-base font-black text-white uppercase tracking-tighter">{level.gameType?.replace('_', ' ')}</div>
                </div>
                
                {isUnlocked ? (
                  <div className="bg-gradient-to-b from-green-400 to-green-600 p-4 md:p-6 rounded-[1.5rem] md:rounded-[2rem] shadow-[0_6px_0_#166534,0_10px_20px_rgba(0,0,0,0.3)] group-hover:shadow-[0_2px_0_#166534,0_5px_10px_rgba(0,0,0,0.3)] group-hover:translate-y-1 transition-all border-2 border-green-300">
                    <Play className="text-white fill-white w-8 h-8 md:w-10 md:h-10 ml-1" />
                  </div>
                ) : (
                  <div className="bg-black/30 p-4 md:p-6 rounded-[1.5rem] md:rounded-[2rem] border-2 border-white/10 shadow-inner">
                    <Lock className="text-white/50 w-8 h-8 md:w-10 md:h-10" />
                  </div>
                )}
              </div>

              {level.isBoss && isUnlocked && (
                <motion.div 
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="absolute -top-2 -right-2 md:-top-4 md:-right-4 bg-gradient-to-b from-red-500 to-red-700 text-white px-6 py-3 md:px-8 md:py-4 rounded-full text-sm md:text-base font-black shadow-[0_10px_20px_rgba(220,38,38,0.5)] border-4 border-white z-20 transform rotate-12"
                >
                  BOSS!
                </motion.div>
              )}
            </motion.button>
          );
        })}
      </div>

      {/* Grounded Island Base */}
      <div className={`fixed bottom-0 left-0 right-0 h-24 ${island.groundColor || 'bg-green-500'} rounded-t-[100%] scale-x-[1.5] transform origin-bottom shadow-[inset_0_20px_40px_rgba(0,0,0,0.2)] border-t-8 border-white/20 z-0 pointer-events-none`} />
    </div>
  );
};

export default IslandLevels;
