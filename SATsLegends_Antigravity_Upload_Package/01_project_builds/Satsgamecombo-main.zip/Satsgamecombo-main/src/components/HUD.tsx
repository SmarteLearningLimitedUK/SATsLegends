import React from 'react';
import { motion } from 'motion/react';
import { Timer, Trophy, Star } from 'lucide-react';
import { AvatarData, CloudCollapseLevelConfig } from '../types';

interface HUDProps {
  score: number;
  targetScore: number;
  timeLeft: number;
  level: CloudCollapseLevelConfig;
  avatar: AvatarData;
}

const HUD: React.FC<HUDProps> = ({ score, targetScore, timeLeft, level, avatar }) => {
  const progress = Math.min((score / targetScore) * 100, 100);

  return (
    <div className="w-full max-w-2xl px-2 md:px-4 py-1 flex flex-col gap-2 md:gap-4">
      <div className="flex items-center justify-between bg-white/40 backdrop-blur-xl p-2 md:p-4 rounded-[1.5rem] md:rounded-[2rem] border-2 md:border-4 border-white/60 shadow-[0_10px_30px_rgba(0,0,0,0.1)]">
        <div className="flex items-center gap-2 md:gap-4">
          <motion.div 
            whileHover={{ scale: 1.1, rotate: 5 }}
            className={`${avatar.color} w-10 h-10 md:w-16 md:h-16 rounded-xl md:rounded-3xl flex items-center justify-center text-xl md:text-3xl shadow-lg border-2 md:border-4 border-white relative overflow-hidden`}
          >
            <div className="shine" />
            {avatar.image}
          </motion.div>
          <div>
            <h2 className="text-sm md:text-xl font-black text-white drop-shadow-md tracking-tight">Level {level.id}</h2>
            <div className="flex items-center gap-1 text-white/90 font-bold text-[10px] md:text-sm">
              <Trophy className="w-3 h-3 md:w-4 md:h-4 text-yellow-400" />
              <span>Target: {targetScore}</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-end gap-0.5 md:gap-1">
          <div className="flex items-center gap-1 md:gap-2 bg-black/10 px-2 md:px-4 py-1 rounded-xl md:rounded-2xl border border-white/20">
            <Timer className={`w-3 h-3 md:w-5 md:h-5 ${timeLeft < 10 ? "text-red-400 animate-pulse" : "text-white"}`} />
            <span className={`text-sm md:text-xl font-black ${timeLeft < 10 ? "text-red-400" : "text-white"}`}>
              {timeLeft}s
            </span>
          </div>
          <motion.div 
            key={score}
            initial={{ scale: 1.5, color: '#fbbf24' }}
            animate={{ scale: 1, color: '#ffffff' }}
            className="text-xl md:text-4xl font-black text-white drop-shadow-[0_4px_4px_rgba(0,0,0,0.3)]"
          >
            {score}
          </motion.div>
        </div>
      </div>

      <div className="relative w-full h-6 md:h-10 bg-black/10 rounded-2xl md:rounded-3xl p-1 md:p-1.5 border-2 md:border-4 border-white/40 shadow-inner overflow-hidden">
        <motion.div 
          className="h-full bg-gradient-to-r from-yellow-300 via-yellow-400 to-orange-500 rounded-xl md:rounded-2xl relative"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ type: 'spring', stiffness: 60, damping: 12 }}
        >
          <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(255,255,255,0.2)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.2)_50%,rgba(255,255,255,0.2)_75%,transparent_75%,transparent)] bg-[length:10px_10px] md:bg-[length:20px_20px] animate-[move-bg_2s_linear_infinite]" />
          <div className="shine rounded-xl md:rounded-2xl" />
        </motion.div>
        <div className="absolute inset-0 flex items-center justify-center text-[10px] md:text-sm font-black text-white drop-shadow-md uppercase tracking-widest">
          {Math.round(progress)}%
        </div>
      </div>

      <style>{`
        @keyframes move-bg {
          from { background-position: 0 0; }
          to { background-position: 40px 0; }
        }
      `}</style>
    </div>
  );
};

export default HUD;
