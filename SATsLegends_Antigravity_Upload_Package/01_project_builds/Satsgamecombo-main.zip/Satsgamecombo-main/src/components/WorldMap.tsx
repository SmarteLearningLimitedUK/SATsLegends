import React, { useRef, useState } from 'react';
import { motion } from 'motion/react';
import { IslandData, PlayerData } from '../types';
import { ISLANDS } from '../constants';
import { Lock, ChevronRight, ChevronLeft, Play } from 'lucide-react';

interface WorldMapProps {
  player: PlayerData;
  onSelectIsland: (island: IslandData) => void;
}

const WorldMap: React.FC<WorldMapProps> = ({ player, onSelectIsland }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const scrollLeft = scrollRef.current.scrollLeft;
    const width = scrollRef.current.clientWidth;
    const index = Math.round(scrollLeft / width);
    if (index !== activeIndex) {
      setActiveIndex(index);
    }
  };

  const scrollTo = (index: number) => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollTo({
      left: index * scrollRef.current.clientWidth,
      behavior: 'smooth'
    });
  };

  return (
    <div className="relative w-full h-full flex flex-col bg-[#0f172a] overflow-hidden font-sans">
      {/* Ocean Background Effect */}
      <div className="absolute inset-0 pointer-events-none opacity-30">
        <div className="absolute inset-0" style={{ 
          backgroundImage: 'radial-gradient(circle at 50% 50%, #1e293b 0%, transparent 80%)',
        }} />
        {/* Animated Waves/Ripples */}
        {Array.from({ length: 5 }).map((_, i) => (
          <motion.div
            key={i}
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.1, 0.2, 0.1],
              rotate: [0, 180, 360]
            }}
            transition={{ 
              duration: 20 + (i * 5), 
              repeat: Infinity, 
              ease: "linear" 
            }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-blue-400/20"
            style={{
              width: `${(i + 1) * 40}vw`,
              height: `${(i + 1) * 40}vw`,
            }}
          />
        ))}
      </div>
      {/* HUD Header */}
      <header className="absolute top-0 left-0 right-0 z-50 p-4 md:p-8 flex flex-wrap justify-between items-start pointer-events-none">
        <div className="flex items-center gap-4 pointer-events-auto">
          <div className="relative group">
            <div className="w-16 h-16 md:w-20 md:h-20 bg-white/10 backdrop-blur-2xl rounded-3xl flex items-center justify-center text-4xl shadow-[0_20px_50px_rgba(0,0,0,0.3)] border-2 border-white/20 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-50" />
              🌟
            </div>
            <div className="absolute -bottom-2 -right-2 bg-yellow-400 text-yellow-950 w-8 h-8 rounded-xl flex items-center justify-center font-black text-sm border-2 border-white shadow-lg">
              {player.level}
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <h1 className="text-2xl md:text-3xl font-black text-white drop-shadow-[0_4px_8px_rgba(0,0,0,0.5)] tracking-tight">{player.playerName}</h1>
            <div className="w-32 md:w-48 h-3 bg-black/40 rounded-full overflow-hidden border border-white/10 shadow-inner">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${(player.xp % 1000) / 10}%` }}
                className="h-full bg-gradient-to-r from-blue-400 to-purple-500"
              />
            </div>
            <div className="text-[10px] font-black text-white/60 uppercase tracking-widest">XP: {player.xp % 1000} / 1000</div>
          </div>
        </div>
        <div className="flex gap-3 md:gap-4 pointer-events-auto">
          <div className="bg-white/10 backdrop-blur-xl px-4 md:px-6 py-2 md:py-3 rounded-2xl text-white font-black shadow-[0_10px_30px_rgba(0,0,0,0.2)] border border-white/20 flex items-center gap-2 md:gap-3 text-lg md:text-xl group hover:bg-white/20 transition-all">
            <span className="text-yellow-400 drop-shadow-md group-hover:scale-125 transition-transform">💰</span>
            {player.coins}
          </div>
          <div className="bg-white/10 backdrop-blur-xl px-4 md:px-6 py-2 md:py-3 rounded-2xl text-white font-black shadow-[0_10px_30px_rgba(0,0,0,0.2)] border border-white/20 flex items-center gap-2 md:gap-3 text-lg md:text-xl group hover:bg-white/20 transition-all">
            <span className="text-blue-400 drop-shadow-md group-hover:scale-125 transition-transform">💎</span>
            {player.gems}
          </div>
        </div>
      </header>

      {/* Navigation Arrows */}
      <div className="absolute top-1/2 left-4 md:left-8 z-40 -translate-y-1/2 pointer-events-auto">
        <button 
          onClick={() => scrollTo(Math.max(0, activeIndex - 1))}
          className={`p-5 rounded-full bg-white/10 backdrop-blur-xl border-4 border-white/30 text-white shadow-[0_10px_30px_rgba(0,0,0,0.3)] transition-all hover:scale-110 hover:bg-white/20 active:scale-95 ${activeIndex === 0 ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
        >
          <ChevronLeft className="w-10 h-10" />
        </button>
      </div>
      <div className="absolute top-1/2 right-4 md:right-8 z-40 -translate-y-1/2 pointer-events-auto">
        <button 
          onClick={() => scrollTo(Math.min(ISLANDS.length - 1, activeIndex + 1))}
          className={`p-5 rounded-full bg-white/10 backdrop-blur-xl border-4 border-white/30 text-white shadow-[0_10px_30px_rgba(0,0,0,0.3)] transition-all hover:scale-110 hover:bg-white/20 active:scale-95 ${activeIndex === ISLANDS.length - 1 ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
        >
          <ChevronRight className="w-10 h-10" />
        </button>
      </div>

      {/* Map Container */}
      <div 
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex-1 w-full h-full flex overflow-x-auto snap-x snap-mandatory hide-scrollbar relative z-10"
      >
        {ISLANDS.map((island, index) => {
          const isLocked = false; // Force unlocked for testing
          const isActive = index === activeIndex;

          return (
            <div 
              key={island.id} 
              className={`min-w-[100vw] h-full relative snap-center flex flex-col items-center justify-center overflow-hidden`}
            >
              {/* Island Background Gradient (Atmosphere) */}
              <div className={`absolute inset-0 bg-gradient-to-b ${island.bgGradient || 'from-sky-400 to-sky-200'} opacity-50 transition-opacity duration-1000 ${isActive ? 'opacity-100' : 'opacity-0'}`} />

              {/* Floating Island Group */}
              <motion.div
                animate={{ 
                  y: isActive ? [0, -20, 0] : 0,
                }}
                transition={{ 
                  duration: 6, 
                  repeat: Infinity, 
                  ease: "easeInOut" 
                }}
                className="relative z-20 flex flex-col items-center w-full max-w-4xl px-4"
              >
                {/* The Island Base */}
                <div className="relative w-[300px] h-[150px] md:w-[500px] md:h-[250px] mb-8">
                  {/* Island Top (Grass/Surface) */}
                  <div className={`absolute inset-0 ${island.groundColor || 'bg-green-500'} rounded-[100%] shadow-[inset_0_10px_20px_rgba(255,255,255,0.3),0_10px_40px_rgba(0,0,0,0.2)] border-b-[10px] border-black/20 z-10`} />
                  
                  {/* Island Bottom (Rock/Dirt) */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 w-[90%] h-full bg-stone-700 rounded-b-[100%] shadow-[inset_0_-20px_40px_rgba(0,0,0,0.5)] border-t-[10px] border-black/30" />
                  
                  {/* Island Shadow on "Water" */}
                  <motion.div 
                    animate={{ 
                      scale: isActive ? [1, 1.1, 1] : 1,
                      opacity: isActive ? [0.3, 0.2, 0.3] : 0
                    }}
                    transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute -bottom-12 left-1/2 -translate-x-1/2 w-[80%] h-12 bg-black/40 rounded-[100%] blur-xl z-0"
                  />
                  
                  {/* Decorations on the Island */}
                  <div className="absolute inset-0 z-20 pointer-events-none">
                    {island.decorations?.map((dec, i) => (
                      <motion.div
                        key={i}
                        initial={{ scale: 0 }}
                        animate={{ scale: isActive ? 1 : 0 }}
                        transition={{ delay: 0.3 + (i * 0.1), type: 'spring' }}
                        className="absolute text-5xl md:text-7xl drop-shadow-lg"
                        style={{
                          bottom: `${20 + (Math.random() * 40)}%`,
                          left: `${10 + (i * 25)}%`,
                          transform: `rotate(${(Math.random() - 0.5) * 30}deg)`
                        }}
                      >
                        {dec}
                      </motion.div>
                    ))}
                  </div>

                  {/* Floating Particles around Island */}
                  <div className="absolute -inset-20 z-0 pointer-events-none">
                    {Array.from({ length: 8 }).map((_, i) => (
                      <motion.div
                        key={i}
                        animate={{ 
                          y: [0, -40, 0],
                          x: [0, (i % 2 === 0 ? 20 : -20), 0],
                          opacity: [0.2, 0.5, 0.2]
                        }}
                        transition={{ 
                          duration: 3 + i, 
                          repeat: Infinity, 
                          delay: i * 0.5 
                        }}
                        className="absolute w-2 h-2 bg-white rounded-full blur-sm"
                        style={{
                          top: `${Math.random() * 100}%`,
                          left: `${Math.random() * 100}%`,
                        }}
                      />
                    ))}
                  </div>
                </div>

                {/* Island Info */}
                <div className="flex flex-col items-center text-center">
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: isActive ? 1 : 0, y: isActive ? 0 : 20 }}
                    className="bg-black/40 backdrop-blur-md px-6 py-2 rounded-full text-white/90 font-black uppercase tracking-[0.3em] text-xs md:text-sm mb-4 border border-white/20 shadow-lg"
                  >
                    ZONE {index + 1} • {island.category}
                  </motion.div>
                  
                  <motion.h2 
                    initial={{ opacity: 0, scale: 0.5 }}
                    animate={{ opacity: isActive ? 1 : 0, scale: isActive ? 1 : 0.5 }}
                    className="text-5xl md:text-8xl font-black text-white drop-shadow-[0_8px_0_rgba(0,0,0,0.3)] tracking-tighter mb-2 leading-none"
                  >
                    {island.themeName || island.name}
                  </motion.h2>
                  
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: isActive ? 0.8 : 0 }}
                    className="text-xl md:text-2xl font-bold text-white/80 mb-10"
                  >
                    {island.name}
                  </motion.div>

                  <motion.button
                    whileHover={!isLocked ? { scale: 1.05, y: -5 } : {}}
                    whileTap={!isLocked ? { scale: 0.95, y: 5 } : {}}
                    onClick={() => !isLocked && onSelectIsland(island)}
                    disabled={isLocked}
                    className={`
                      relative group flex items-center justify-center gap-4 px-10 py-6 rounded-[2.5rem] font-black text-3xl md:text-4xl transition-all w-full max-w-xs
                      ${isLocked 
                        ? 'bg-gray-600 text-gray-400 cursor-not-allowed border-b-[8px] border-gray-800 shadow-xl' 
                        : 'bg-gradient-to-b from-yellow-400 to-orange-500 text-white border-b-[8px] border-orange-700 shadow-[0_20px_40px_rgba(0,0,0,0.3)] hover:shadow-[0_30px_60px_rgba(251,191,36,0.4)]'}
                    `}
                  >
                    {isLocked ? (
                      <>
                        <Lock className="w-8 h-8" />
                        LOCKED
                      </>
                    ) : (
                      <>
                        <Play className="w-10 h-10 fill-current" />
                        EXPLORE
                      </>
                    )}
                    
                    {/* Button Gloss */}
                    {!isLocked && (
                      <div className="absolute top-2 left-4 right-4 h-1/3 bg-gradient-to-b from-white/40 to-transparent rounded-full pointer-events-none" />
                    )}
                  </motion.button>
                </div>
              </motion.div>

              {/* Bottom Clouds/Mist */}
              <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white/20 to-transparent pointer-events-none z-30" />
            </div>
          );
        })}
      </div>

      {/* Progress Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-50 flex gap-3 bg-black/30 p-3 rounded-full backdrop-blur-md border border-white/10">
        {ISLANDS.map((_, i) => (
          <button 
            key={i} 
            onClick={() => scrollTo(i)}
            className={`w-3 h-3 rounded-full transition-all duration-500 ${i === activeIndex ? 'bg-yellow-400 scale-150 shadow-[0_0_15px_rgba(250,204,21,1)]' : 'bg-white/30 hover:bg-white/50'}`}
          />
        ))}
      </div>
    </div>
  );
};

export default WorldMap;
