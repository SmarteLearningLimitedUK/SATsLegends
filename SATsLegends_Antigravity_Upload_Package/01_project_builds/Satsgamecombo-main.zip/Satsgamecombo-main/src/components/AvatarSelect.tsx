import React from 'react';
import { motion } from 'motion/react';
import { Check } from 'lucide-react';
import { AVATARS } from '../constants';

interface AvatarSelectProps {
  selectedId: string;
  onSelect: (id: string) => void;
  onConfirm: () => void;
}

const AvatarSelect: React.FC<AvatarSelectProps> = ({ selectedId, onSelect, onConfirm }) => {
  return (
    <div className="w-full max-w-4xl p-6 md:p-12 flex flex-col items-center gap-8 md:gap-12 bg-white/20 backdrop-blur-xl rounded-[3rem] md:rounded-[4rem] border-4 md:border-8 border-white/30 shadow-[0_40px_100px_rgba(0,0,0,0.3)] relative overflow-hidden my-auto">
      {/* Background Glow */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-blue-400/20 rounded-full blur-[100px]" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-purple-400/20 rounded-full blur-[100px]" />

      <div className="text-center relative z-10">
        <h1 className="text-4xl md:text-6xl font-black text-white drop-shadow-[0_4px_0_rgba(0,0,0,0.2)] tracking-tight">
          Choose Your Hero
        </h1>
        <p className="text-white/70 font-bold mt-2 uppercase tracking-widest text-[10px] md:text-sm">Select your companion for the journey</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 md:gap-6 relative z-10 overflow-y-auto max-h-[50vh] md:max-h-none p-2">
        {AVATARS.map((avatar) => (
          <motion.button
            key={avatar.id}
            whileHover={{ scale: 1.05, y: -5 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelect(avatar.id)}
            className={`
              relative group p-4 md:p-6 rounded-[2rem] md:rounded-[2.5rem] flex flex-col items-center gap-2 md:gap-4 border-b-[6px] md:border-b-[10px] transition-all
              ${avatar.color}
              ${selectedId === avatar.id ? 'border-yellow-400 scale-105 shadow-2xl' : 'border-black/10 shadow-xl'}
            `}
          >
            <div className="text-4xl md:text-6xl filter drop-shadow-xl group-hover:scale-110 transition-transform">
              {avatar.image}
            </div>
            <div className="text-[8px] md:text-[10px] font-black text-black/40 uppercase tracking-tighter">
              {avatar.rarity}
            </div>
            
            {selectedId === avatar.id && (
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-2 -right-2 md:-top-3 md:-right-3 bg-gradient-to-b from-yellow-300 to-yellow-500 text-white rounded-xl md:rounded-2xl p-1.5 md:p-2 shadow-xl border-2 border-white"
              >
                <Check className="w-4 h-4 md:w-6 md:h-6 stroke-[4px]" />
              </motion.div>
            )}
          </motion.button>
        ))}
      </div>

      <motion.button
        whileHover={{ scale: 1.05, y: -5 }}
        whileTap={{ scale: 0.95 }}
        onClick={onConfirm}
        className="relative z-10 px-12 md:px-20 py-4 md:py-6 bg-gradient-to-b from-emerald-400 to-emerald-600 text-white text-xl md:text-3xl font-black rounded-[2rem] md:rounded-[2.5rem] shadow-[0_8px_0_#059669] md:shadow-[0_12px_0_#059669] hover:shadow-[0_5px_0_#059669] md:hover:shadow-[0_8px_0_#059669] active:shadow-none transition-all"
      >
        LET'S GO!
      </motion.button>
    </div>
  );
};

export default AvatarSelect;
