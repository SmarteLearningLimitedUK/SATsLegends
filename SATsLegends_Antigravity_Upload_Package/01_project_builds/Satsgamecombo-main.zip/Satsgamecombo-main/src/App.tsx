import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  GameScreen, 
  PlayerData, 
  IslandData, 
  LevelData 
} from './types';
import { INITIAL_DAILY_QUESTS, ACHIEVEMENTS } from './constants';
import WorldMap from './components/WorldMap';
import IslandLevels from './components/IslandLevels';
import CloudCollapseGame from './components/CloudCollapseGame';
import PotionPourGame from './components/PotionPourGame';
import BurgerBuilderGame from './components/BurgerBuilderGame';
import FractionMatchGame from './components/FractionMatchGame';
import PrimePopGame from './components/PrimePopGame';
import AngleArenaGame from './components/AngleArenaGame';
import PolygonPalaceGame from './components/PolygonPalaceGame';
import DataDungeonGame from './components/DataDungeonGame';
import MonsterMarketGame from './components/MonsterMarketGame';
import RatioRapidsGame from './components/RatioRapidsGame';
import TimekeeperTempleGame from './components/TimekeeperTempleGame';
import MeasurementForgeGame from './components/MeasurementForgeGame';
import TowerOfFactorsGame from './components/TowerOfFactorsGame';
import ReasoningGame from './components/reasoning/ReasoningGame';
import AvatarSelect from './components/AvatarSelect';
import DailyRewardsModal from './components/modals/DailyRewardsModal';
import DailyQuestsModal from './components/modals/DailyQuestsModal';
import AchievementsModal from './components/modals/AchievementsModal';
import ParentDashboard from './components/ParentDashboard';
import { Trophy, Home, Settings, User, ShoppingBag, ClipboardList, Medal } from 'lucide-react';

const App: React.FC = () => {
  // --- State ---
  const [screen, setScreen] = useState<GameScreen>('splash');
  const [player, setPlayer] = useState<PlayerData>(() => {
    const saved = localStorage.getItem('maths_quest_player');
    const parsed = saved ? JSON.parse(saved) : null;
    
    return {
      playerName: parsed?.playerName || 'Explorer',
      avatarId: parsed?.avatarId || 'green_slime',
      level: parsed?.level || 1,
      xp: parsed?.xp || 0,
      coins: parsed?.coins || 100,
      gems: parsed?.gems || 10,
      unlockedIslands: parsed?.unlockedIslands || [1, 2, 3, 4, 5, 6],
      completedLevels: parsed?.completedLevels || {},
      dailyStreak: parsed?.dailyStreak || 1,
      claimedDailyRewardToday: parsed?.claimedDailyRewardToday || false,
      dailyQuests: parsed?.dailyQuests || INITIAL_DAILY_QUESTS,
      achievements: parsed?.achievements || [],
      stats: parsed?.stats || {
        totalStars: 0,
        totalGamesPlayed: 0
      }
    };
  });

  const [selectedIsland, setSelectedIsland] = useState<IslandData | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<LevelData | null>(null);
  const [showDailyRewards, setShowDailyRewards] = useState(false);
  const [showQuests, setShowQuests] = useState(false);
  const [showAchievements, setShowAchievements] = useState(false);

  // --- Daily Login Logic ---
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    if (player.lastLoginDate !== today) {
      setPlayer(prev => {
        const wasYesterday = prev.lastLoginDate === new Date(Date.now() - 86400000).toISOString().split('T')[0];
        return {
          ...prev,
          lastLoginDate: today,
          dailyStreak: wasYesterday ? prev.dailyStreak + 1 : 1,
          claimedDailyRewardToday: false,
          dailyQuests: INITIAL_DAILY_QUESTS
        };
      });
      setShowDailyRewards(true);
    }
  }, [player.lastLoginDate]);

  // --- Persistence ---
  useEffect(() => {
    localStorage.setItem('maths_quest_player', JSON.stringify(player));
  }, [player]);

  // --- Handlers ---
  const handleIslandSelect = (island: IslandData) => {
    setSelectedIsland(island);
    setScreen('island_levels');
  };

  const handleLevelSelect = (level: LevelData) => {
    setSelectedLevel(level);
    setScreen('gameplay');
  };

  const handleGameVictory = (stars: number, score: number) => {
    if (!selectedIsland || !selectedLevel) return;

    setPlayer(prev => {
      const islandId = selectedIsland.id;
      const levelId = selectedLevel.id;
      
      const completedLevels = { ...prev.completedLevels };
      if (!completedLevels[islandId]) completedLevels[islandId] = [];
      if (!completedLevels[islandId].includes(levelId)) {
        completedLevels[islandId].push(levelId);
      }

      // Update Daily Quests
      const updatedQuests = prev.dailyQuests.map(q => {
        if (q.id === 'q1') return { ...q, current: q.current + 1 };
        if (q.id === 'q2' && stars === 3) return { ...q, current: q.current + 1 };
        return q;
      });

      const newXp = prev.xp + (stars * 100);
      const xpPerLevel = 1000;
      const newLevel = Math.floor(newXp / xpPerLevel) + 1;
      
      const newStats = {
        totalStars: (prev.stats?.totalStars || 0) + stars,
        totalGamesPlayed: (prev.stats?.totalGamesPlayed || 0) + 1
      };

      const newAchievements = [...(prev.achievements || [])];
      ACHIEVEMENTS.forEach(ach => {
        if (!newAchievements.includes(ach.id)) {
          let unlocked = false;
          if (ach.type === 'levels' && Object.values(completedLevels).flat().length >= ach.target) unlocked = true;
          if (ach.type === 'stars' && newStats.totalStars >= ach.target) unlocked = true;
          if (ach.type === 'coins' && (prev.coins + (stars * 50)) >= ach.target) unlocked = true;
          if (ach.type === 'streak' && prev.dailyStreak >= ach.target) unlocked = true;

          if (unlocked) newAchievements.push(ach.id);
        }
      });

      return {
        ...prev,
        coins: prev.coins + (stars * 50),
        xp: newXp,
        level: newLevel,
        completedLevels,
        dailyQuests: updatedQuests,
        stats: newStats,
        achievements: newAchievements
      };
    });

    setScreen('world_map');
  };

  const handleGameOver = (score: number) => {
    setScreen('island_levels');
  };

  const handleClaimDailyReward = (reward: { type: string, amount: number }) => {
    setPlayer(prev => ({
      ...prev,
      coins: reward.type === 'coins' ? prev.coins + reward.amount : prev.coins,
      gems: reward.type === 'gems' ? prev.gems + reward.amount : prev.gems,
      claimedDailyRewardToday: true
    }));
    setShowDailyRewards(false);
  };

  const handleClaimQuest = (questId: string) => {
    setPlayer(prev => {
      const quest = prev.dailyQuests.find(q => q.id === questId);
      if (!quest || quest.isClaimed) return prev;

      return {
        ...prev,
        coins: quest.reward.type === 'coins' ? prev.coins + quest.reward.amount : prev.coins,
        gems: quest.reward.type === 'gems' ? prev.gems + quest.reward.amount : prev.gems,
        xp: quest.reward.type === 'xp' ? prev.xp + quest.reward.amount : prev.xp,
        dailyQuests: prev.dailyQuests.map(q => q.id === questId ? { ...q, isClaimed: true } : q)
      };
    });
  };

  // --- Render Helpers ---
  const renderScreen = () => {
    switch (screen) {
      case 'splash':
        return (
          <div className="flex flex-col items-center gap-16 relative my-auto">
            {/* Animated Background Elements */}
            <div className="absolute -z-10 w-[150%] h-[150%] flex items-center justify-center opacity-20">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="w-[800px] h-[800px] border-[40px] border-dashed border-white rounded-full"
              />
              <motion.div 
                animate={{ rotate: -360 }}
                transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                className="absolute w-[600px] h-[600px] border-[20px] border-dotted border-white rounded-full"
              />
            </div>

            <motion.div
              initial={{ y: -50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 100, damping: 15 }}
              className="text-center relative"
            >
              <div className="absolute -top-20 left-1/2 -translate-x-1/2 flex gap-4">
                {['➕', '➖', '✖️', '➗'].map((emoji, i) => (
                  <motion.span
                    key={i}
                    animate={{ y: [0, -20, 0] }}
                    transition={{ duration: 2, repeat: Infinity, delay: i * 0.5 }}
                    className="text-4xl filter drop-shadow-lg"
                  >
                    {emoji}
                  </motion.span>
                ))}
              </div>
              <h1 className="text-5xl sm:text-7xl md:text-8xl lg:text-[10rem] leading-none font-black text-white drop-shadow-[0_10px_0_rgba(0,0,0,0.2)] tracking-tighter">
                SATS<br/>
                <span className="text-yellow-400 drop-shadow-[0_10px_0_#ca8a04]">MASTERY</span>
              </h1>
              <p className="text-lg sm:text-xl md:text-3xl font-bold text-white/90 mt-4 md:mt-6 tracking-widest uppercase bg-black/10 backdrop-blur-sm px-6 md:px-8 py-2 rounded-full inline-block">
                The Ultimate Adventure
              </p>
            </motion.div>
            
            <div className="flex flex-col items-center gap-6">
              <motion.button
                whileHover={{ scale: 1.05, y: -5 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setScreen('world_map')}
                className="group relative px-20 py-8 bg-gradient-to-b from-yellow-300 to-yellow-500 text-white text-5xl font-black rounded-[3rem] shadow-[0_15px_0_#ca8a04] hover:shadow-[0_10px_0_#ca8a04] active:shadow-none transition-all"
              >
                <span className="relative z-10">PLAY NOW</span>
                <div className="absolute inset-0 bg-white/20 rounded-[3rem] opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.button>
              
              <div className="flex gap-4">
                <motion.div 
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="px-6 py-2 bg-white/20 backdrop-blur-md rounded-full text-white font-bold text-sm border border-white/30"
                >
                  v2.0 AAA EDITION
                </motion.div>
              </div>
            </div>

            {/* Floating Avatars */}
            <div className="absolute -bottom-20 -left-40 opacity-40 blur-sm">
              <span className="text-9xl">🟢</span>
            </div>
            <div className="absolute -top-20 -right-40 opacity-40 blur-sm">
              <span className="text-9xl">🧚</span>
            </div>
          </div>
        );

      case 'world_map':
        return <WorldMap player={player} onSelectIsland={handleIslandSelect} />;

      case 'island_levels':
        return (
          <IslandLevels 
            island={selectedIsland!} 
            player={player} 
            onBack={() => setScreen('world_map')} 
            onSelectLevel={handleLevelSelect}
          />
        );

      case 'gameplay':
        if (selectedLevel?.gameType === 'cloud_collapse') {
          return (
            <CloudCollapseGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }
        
        if (selectedLevel?.gameType === 'potion_pour') {
          return (
            <PotionPourGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }
        
        if (selectedLevel?.gameType === 'burger_builder' || selectedLevel?.gameType === 'burger_bar') {
          return (
            <BurgerBuilderGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        if (selectedLevel?.gameType === 'fraction_match') {
          return (
            <FractionMatchGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        if (selectedLevel?.gameType === 'prime_pop') {
          return (
            <PrimePopGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        if (selectedLevel?.gameType === 'angle_arena') {
          return (
            <AngleArenaGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        if (selectedLevel?.gameType === 'polygon_palace') {
          return (
            <PolygonPalaceGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        if (selectedLevel?.gameType === 'data_dungeon') {
          return (
            <DataDungeonGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        if (selectedLevel?.gameType === 'monster_market') {
          return (
            <MonsterMarketGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        if (selectedLevel?.gameType === 'ratio_rapids') {
          return (
            <RatioRapidsGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        if (selectedLevel?.gameType === 'timekeeper_temple') {
          return (
            <TimekeeperTempleGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        if (selectedLevel?.gameType === 'measurement_forge') {
          return (
            <MeasurementForgeGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        if (selectedLevel?.gameType === 'tower_of_factors') {
          return (
            <TowerOfFactorsGame 
              levelId={selectedLevel.id}
              avatarId={player.avatarId}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        if (['sequence_sprint', 'logic_sort', 'shape_shift', 'matrix_match'].includes(selectedLevel?.gameType || '')) {
          return (
            <ReasoningGame 
              gameType={selectedLevel!.gameType!}
              onVictory={handleGameVictory}
              onGameOver={handleGameOver}
              onBack={() => setScreen('island_levels')}
            />
          );
        }

        return (
          <div className="flex flex-col items-center gap-8 p-12 bg-white/20 backdrop-blur-xl rounded-[3rem] border-8 border-white/50 my-auto">
            <h2 className="text-4xl font-black text-white">Coming Soon!</h2>
            <p className="text-xl text-white/80 text-center">
              The {selectedLevel?.gameType?.replace('_', ' ')} mini-game is currently under development.
              <br/>Try a Fractions level to play Sats Mastery!
            </p>
            <button 
              onClick={() => setScreen('island_levels')}
              className="px-8 py-4 bg-white/40 text-white font-black rounded-2xl border-b-4 border-white/60"
            >
              GO BACK
            </button>
          </div>
        );

      case 'avatar_selection':
        return (
          <AvatarSelect 
            selectedId={player.avatarId}
            onSelect={(id) => setPlayer(prev => ({ ...prev, avatarId: id }))}
            onConfirm={() => setScreen('world_map')}
          />
        );

      case 'parent_dashboard':
        return <ParentDashboard player={player} onBack={() => setScreen('world_map')} />;

      default:
        return <div className="text-white">Screen {screen} not implemented</div>;
    }
  };

  return (
    <div className={`h-screen w-full flex flex-col items-center overflow-hidden ${['world_map', 'island_levels'].includes(screen) ? 'bg-slate-900' : 'cloud-bg p-2 md:p-8'}`}>
      <AnimatePresence mode="wait">
        <motion.div
          key={screen}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 1.1 }}
          className={`w-full flex-1 flex justify-center relative z-10 overflow-hidden ${['world_map', 'island_levels'].includes(screen) ? '' : 'max-w-7xl mx-auto'}`}
        >
          {renderScreen()}
        </motion.div>
      </AnimatePresence>

      <DailyRewardsModal 
        isOpen={showDailyRewards}
        onClose={() => setShowDailyRewards(false)}
        streak={player.dailyStreak}
        claimedToday={player.claimedDailyRewardToday}
        onClaim={handleClaimDailyReward}
      />

      <DailyQuestsModal 
        isOpen={showQuests}
        onClose={() => setShowQuests(false)}
        quests={player.dailyQuests}
        onClaimQuest={handleClaimQuest}
      />

      <AchievementsModal
        isOpen={showAchievements}
        onClose={() => setShowAchievements(false)}
        player={player}
      />

      {/* Global Background Clouds */}
      {!['world_map', 'island_levels'].includes(screen) && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="cloud w-64 h-24 top-20" style={{ animationDuration: '25s' }} />
          <div className="cloud w-48 h-16 top-40" style={{ animationDuration: '40s', animationDelay: '-10s' }} />
          <div className="cloud w-80 h-32 bottom-20" style={{ animationDuration: '30s', animationDelay: '-5s' }} />
        </div>
      )}

      {/* Navigation Bar (only on certain screens) */}
      {['world_map', 'shop', 'profile'].includes(screen) && (
        <nav className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-white/30 backdrop-blur-xl px-8 py-4 rounded-full border-2 border-white/50 shadow-2xl flex gap-8 md:gap-12 z-50">
          <button onClick={() => setScreen('world_map')} className={`p-2 rounded-2xl transition-all ${screen === 'world_map' ? 'bg-white text-blue-500 scale-110 shadow-lg' : 'text-white hover:bg-white/20'}`}>
            <Home />
          </button>
          <button onClick={() => setScreen('avatar_selection')} className={`p-2 rounded-2xl transition-all ${screen === 'avatar_selection' ? 'bg-white text-blue-500 scale-110 shadow-lg' : 'text-white hover:bg-white/20'}`}>
            <User />
          </button>
          <button onClick={() => setShowQuests(true)} className="p-2 rounded-2xl text-white hover:bg-white/20 transition-all relative">
            <ClipboardList />
            {(player.dailyQuests || []).some(q => q.current >= q.target && !q.isClaimed) && (
              <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full border-2 border-white animate-pulse" />
            )}
          </button>
          <button onClick={() => setShowAchievements(true)} className="p-2 rounded-2xl text-white hover:bg-white/20 transition-all relative">
            <Medal />
            {(player.achievements?.length || 0) > 0 && (
              <span className="absolute top-0 right-0 w-3 h-3 bg-yellow-400 rounded-full border-2 border-white" />
            )}
          </button>
          <button onClick={() => setScreen('parent_dashboard')} className="p-2 rounded-2xl text-white hover:bg-white/20 transition-all">
            <Settings />
          </button>
        </nav>
      )}
    </div>
  );
};

export default App;
