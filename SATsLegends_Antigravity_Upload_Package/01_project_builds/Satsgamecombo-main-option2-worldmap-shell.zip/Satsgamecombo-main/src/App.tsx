import React, { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ClipboardList, Home, Medal, Settings, User } from 'lucide-react';
import { ACHIEVEMENTS, INITIAL_DAILY_QUESTS } from './constants';
import { GameScreen, IslandData, LevelData, PlayerData } from './types';
import WorldMap from './components/WorldMap';
import IslandLevels from './components/IslandLevels';
import CloudCollapseGame from './components/CloudCollapseGame';
import PotionPourGame from './components/PotionPourGame';
import BurgerBuilderGame from './components/BurgerBuilderGame';
import FractionMatchGame from './components/FractionMatchGame';
import PrimePopGame from './components/PrimePopGame';
import AngleArenaGame from './components/AngleArenaGame';
import PolygonPalaceGame from './components/PolygonPalaceGame';
import DataDungeonGame from './components/DataDungeonGame';
import MonsterMarketGame from './components/MonsterMarketGame';
import RatioRapidsGame from './components/RatioRapidsGame';
import TimekeeperTempleGame from './components/TimekeeperTempleGame';
import MeasurementForgeGame from './components/MeasurementForgeGame';
import TowerOfFactorsGame from './components/TowerOfFactorsGame';
import ReasoningGame from './components/reasoning/ReasoningGame';
import AvatarSelect from './components/AvatarSelect';
import DailyRewardsModal from './components/modals/DailyRewardsModal';
import DailyQuestsModal from './components/modals/DailyQuestsModal';
import AchievementsModal from './components/modals/AchievementsModal';
import ParentDashboard from './components/ParentDashboard';

const PLAYER_STORAGE_KEY = 'maths_quest_player';

const createDefaultPlayer = (parsed?: Partial<PlayerData> | null): PlayerData => ({
  playerName: parsed?.playerName || '',
  avatarId: parsed?.avatarId || 'green_slime',
  level: parsed?.level || 1,
  xp: parsed?.xp || 0,
  coins: parsed?.coins || 100,
  gems: parsed?.gems || 10,
  unlockedIslands: parsed?.unlockedIslands || [1],
  completedLevels: parsed?.completedLevels || {},
  levelStars: parsed?.levelStars || {},
  lastLoginDate: parsed?.lastLoginDate,
  dailyStreak: parsed?.dailyStreak || 1,
  claimedDailyRewardToday: parsed?.claimedDailyRewardToday || false,
  dailyQuests: parsed?.dailyQuests || INITIAL_DAILY_QUESTS,
  achievements: parsed?.achievements || [],
  customSpriteUrl: parsed?.customSpriteUrl,
  stats: parsed?.stats || {
    totalStars: 0,
    totalGamesPlayed: 0,
  },
});

const App: React.FC = () => {
  const [screen, setScreen] = useState<GameScreen>('splash');
  const [player, setPlayer] = useState<PlayerData>(() => {
    const saved = localStorage.getItem(PLAYER_STORAGE_KEY);
    const parsed = saved ? JSON.parse(saved) : null;
    return createDefaultPlayer(parsed);
  });
  const [draftName, setDraftName] = useState('');
  const [selectedIsland, setSelectedIsland] = useState<IslandData | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<LevelData | null>(null);
  const [showDailyRewards, setShowDailyRewards] = useState(false);
  const [showQuests, setShowQuests] = useState(false);
  const [showAchievements, setShowAchievements] = useState(false);

  const hasCompletedProfile = useMemo(
    () => Boolean(player.playerName.trim() && player.avatarId),
    [player.playerName, player.avatarId],
  );

  useEffect(() => {
    if (screen === 'profile_setup' && !draftName) {
      setDraftName(player.playerName || 'Explorer');
    }
  }, [screen, draftName, player.playerName]);

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    if (player.lastLoginDate !== today) {
      setPlayer(prev => {
        const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
        const wasYesterday = prev.lastLoginDate === yesterday;

        return {
          ...prev,
          lastLoginDate: today,
          dailyStreak: wasYesterday ? prev.dailyStreak + 1 : 1,
          claimedDailyRewardToday: false,
          dailyQuests: INITIAL_DAILY_QUESTS.map(quest => ({ ...quest })),
        };
      });
      setShowDailyRewards(true);
    }
  }, [player.lastLoginDate]);

  useEffect(() => {
    localStorage.setItem(PLAYER_STORAGE_KEY, JSON.stringify(player));
  }, [player]);

  const goToHome = () => {
    setSelectedLevel(null);
    setScreen('world_map');
  };

  const handleStartAdventure = () => {
    if (!player.playerName.trim()) {
      setDraftName('Explorer');
      setScreen('profile_setup');
      return;
    }

    setScreen('avatar_selection');
  };

  const handleSaveProfileName = () => {
    const sanitizedName = draftName.trim() || 'Explorer';
    setPlayer(prev => ({ ...prev, playerName: sanitizedName }));
    setScreen('avatar_selection');
  };

  const handleAvatarConfirm = () => {
    setScreen('world_map');
  };

  const handleIslandSelect = (island: IslandData) => {
    setSelectedIsland(island);
    setSelectedLevel(null);
    setScreen('island_levels');
  };

  const handleLevelSelect = (level: LevelData) => {
    setSelectedLevel(level);
    setScreen('gameplay');
  };

  const handleGameVictory = (stars: number, score: number) => {
    if (!selectedIsland || !selectedLevel) return;

    setPlayer(prev => {
      const islandId = selectedIsland.id;
      const levelId = selectedLevel.id;
      const completedLevels = { ...prev.completedLevels };
      const levelStars = { ...prev.levelStars };

      if (!completedLevels[islandId]) completedLevels[islandId] = [];
      if (!completedLevels[islandId].includes(levelId)) {
        completedLevels[islandId] = [...completedLevels[islandId], levelId];
      }
      const levelStarKey = `${islandId}-${levelId}`;
      levelStars[levelStarKey] = Math.max(levelStars[levelStarKey] || 0, stars);

      const updatedQuests = prev.dailyQuests.map(quest => {
        if (quest.id === 'q1') {
          return { ...quest, current: Math.min(quest.target, quest.current + 1) };
        }
        if (quest.id === 'q2' && stars === 3) {
          return { ...quest, current: Math.min(quest.target, quest.current + 1) };
        }
        return quest;
      });

      const earnedCoins = stars * 50;
      const earnedXp = stars * 100;
      const totalXp = prev.xp + earnedXp;
      const level = Math.floor(totalXp / 1000) + 1;
      const totalTrackedStars = Object.values(levelStars).reduce((sum, value) => sum + value, 0);
      const stats = {
        totalStars: totalTrackedStars,
        totalGamesPlayed: (prev.stats?.totalGamesPlayed || 0) + 1,
      };

      const achievements = [...(prev.achievements || [])];
      const totalCompletedLevels = Object.values(completedLevels).flat().length;
      const nextCoinTotal = prev.coins + earnedCoins;
      const unlockedIslands = prev.unlockedIslands.includes(islandId + 1) || !selectedLevel.isBoss
        ? prev.unlockedIslands
        : [...prev.unlockedIslands, islandId + 1].filter(id => id <= 6);

      ACHIEVEMENTS.forEach(achievement => {
        if (achievements.includes(achievement.id)) return;

        let unlocked = false;
        if (achievement.type === 'levels' && totalCompletedLevels >= achievement.target) unlocked = true;
        if (achievement.type === 'stars' && stats.totalStars >= achievement.target) unlocked = true;
        if (achievement.type === 'coins' && nextCoinTotal >= achievement.target) unlocked = true;
        if (achievement.type === 'streak' && prev.dailyStreak >= achievement.target) unlocked = true;

        if (unlocked) achievements.push(achievement.id);
      });

      return {
        ...prev,
        coins: nextCoinTotal,
        xp: totalXp,
        level,
        completedLevels,
        levelStars,
        unlockedIslands,
        dailyQuests: updatedQuests,
        stats,
        achievements,
      };
    });

    setScreen('world_map');
  };

  const handleGameOver = (_score: number) => {
    setScreen('island_levels');
  };

  const handleClaimDailyReward = (reward: { type: string; amount: number }) => {
    setPlayer(prev => ({
      ...prev,
      coins: reward.type === 'coins' ? prev.coins + reward.amount : prev.coins,
      gems: reward.type === 'gems' ? prev.gems + reward.amount : prev.gems,
      claimedDailyRewardToday: true,
    }));
    setShowDailyRewards(false);
  };

  const handleClaimQuest = (questId: string) => {
    setPlayer(prev => {
      const quest = prev.dailyQuests.find(q => q.id === questId);
      if (!quest || quest.isClaimed || quest.current < quest.target) return prev;

      return {
        ...prev,
        coins: quest.reward.type === 'coins' ? prev.coins + quest.reward.amount : prev.coins,
        gems: quest.reward.type === 'gems' ? prev.gems + quest.reward.amount : prev.gems,
        xp: quest.reward.type === 'xp' ? prev.xp + quest.reward.amount : prev.xp,
        dailyQuests: prev.dailyQuests.map(q =>
          q.id === questId ? { ...q, isClaimed: true } : q,
        ),
      };
    });
  };

  const renderGameplay = () => {
    if (!selectedLevel) return null;

    const sharedProps = {
      levelId: selectedLevel.id,
      avatarId: player.avatarId,
      onVictory: handleGameVictory,
      onGameOver: handleGameOver,
      onBack: () => setScreen('island_levels' as GameScreen),
    };

    switch (selectedLevel.gameType) {
      case 'cloud_collapse':
        return <CloudCollapseGame {...sharedProps} />;
      case 'potion_pour':
        return <PotionPourGame {...sharedProps} />;
      case 'burger_builder':
      case 'burger_bar':
        return <BurgerBuilderGame {...sharedProps} />;
      case 'fraction_match':
        return <FractionMatchGame {...sharedProps} />;
      case 'prime_pop':
        return <PrimePopGame {...sharedProps} />;
      case 'angle_arena':
        return <AngleArenaGame {...sharedProps} />;
      case 'polygon_palace':
        return <PolygonPalaceGame {...sharedProps} />;
      case 'data_dungeon':
        return <DataDungeonGame {...sharedProps} />;
      case 'monster_market':
        return <MonsterMarketGame {...sharedProps} />;
      case 'ratio_rapids':
        return <RatioRapidsGame {...sharedProps} />;
      case 'timekeeper_temple':
        return <TimekeeperTempleGame {...sharedProps} />;
      case 'measurement_forge':
        return <MeasurementForgeGame {...sharedProps} />;
      case 'tower_of_factors':
        return <TowerOfFactorsGame {...sharedProps} />;
      case 'sequence_sprint':
      case 'logic_sort':
      case 'shape_shift':
      case 'matrix_match':
        return (
          <ReasoningGame
            gameType={selectedLevel.gameType}
            onVictory={handleGameVictory}
            onGameOver={handleGameOver}
            onBack={() => setScreen('island_levels')}
          />
        );
      default:
        return (
          <div className="flex flex-col items-center gap-6 p-10 bg-white/20 backdrop-blur-xl rounded-[3rem] border-4 border-white/30 my-auto text-center">
            <h2 className="text-4xl font-black text-white">Mini-game incoming</h2>
            <p className="text-white/80 max-w-xl text-lg">
              This slot is wired into the adventure flow, but the gameplay scene is still being built.
            </p>
            <button
              onClick={() => setScreen('island_levels')}
              className="px-8 py-4 bg-white/20 text-white font-black rounded-2xl border-b-4 border-white/30"
            >
              Back to island
            </button>
          </div>
        );
    }
  };

  const renderScreen = () => {
    switch (screen) {
      case 'splash':
        return (
          <div className="flex flex-col items-center gap-14 relative my-auto px-6 text-center">
            <div className="absolute -z-10 w-[150%] h-[150%] flex items-center justify-center opacity-20">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                className="w-[800px] h-[800px] border-[40px] border-dashed border-white rounded-full"
              />
              <motion.div
                animate={{ rotate: -360 }}
                transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
                className="absolute w-[600px] h-[600px] border-[20px] border-dotted border-white rounded-full"
              />
            </div>

            <motion.div
              initial={{ y: -30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 100, damping: 15 }}
            >
              <div className="absolute -top-16 left-1/2 -translate-x-1/2 flex gap-4">
                {['➕', '➖', '✖️', '➗'].map((emoji, i) => (
                  <motion.span
                    key={i}
                    animate={{ y: [0, -16, 0] }}
                    transition={{ duration: 2, repeat: Infinity, delay: i * 0.4 }}
                    className="text-4xl"
                  >
                    {emoji}
                  </motion.span>
                ))}
              </div>
              <h1 className="text-5xl sm:text-7xl md:text-8xl lg:text-[9rem] leading-none font-black text-white tracking-tighter drop-shadow-[0_8px_0_rgba(0,0,0,0.2)]">
                SATS
                <br />
                <span className="text-yellow-400 drop-shadow-[0_8px_0_#ca8a04]">MASTERY</span>
              </h1>
              <p className="mt-5 inline-block rounded-full bg-black/15 backdrop-blur-sm px-6 py-2 text-sm md:text-xl font-bold tracking-[0.25em] uppercase text-white/95">
                World map adventure build
              </p>
            </motion.div>

            <div className="flex flex-col items-center gap-4">
              <motion.button
                whileHover={{ scale: 1.04, y: -3 }}
                whileTap={{ scale: 0.97 }}
                onClick={handleStartAdventure}
                className="group relative px-12 md:px-20 py-6 md:py-8 bg-gradient-to-b from-yellow-300 to-yellow-500 text-white text-3xl md:text-5xl font-black rounded-[2.5rem] shadow-[0_12px_0_#ca8a04] hover:shadow-[0_8px_0_#ca8a04] active:shadow-none transition-all"
              >
                {hasCompletedProfile ? 'CONTINUE' : 'START ADVENTURE'}
              </motion.button>
              <p className="text-white/80 font-bold">
                {hasCompletedProfile ? `Welcome back, ${player.playerName}.` : 'Create your hero and jump into the islands.'}
              </p>
            </div>
          </div>
        );

      case 'profile_setup':
        return (
          <div className="w-full max-w-3xl my-auto rounded-[3rem] border-4 border-white/30 bg-white/15 backdrop-blur-xl p-8 md:p-12 shadow-2xl text-center">
            <div className="mb-8">
              <h2 className="text-4xl md:text-6xl font-black text-white tracking-tight">Name your hero</h2>
              <p className="mt-3 text-white/75 font-bold uppercase tracking-[0.2em] text-xs md:text-sm">
                Step 1 of 2 · profile setup
              </p>
            </div>

            <div className="flex flex-col gap-5 items-center">
              <input
                value={draftName}
                onChange={event => setDraftName(event.target.value.slice(0, 18))}
                onKeyDown={event => {
                  if (event.key === 'Enter') handleSaveProfileName();
                }}
                placeholder="Explorer"
                className="w-full max-w-xl rounded-[1.75rem] border-2 border-white/20 bg-black/20 px-6 py-5 text-center text-2xl md:text-3xl font-black text-white placeholder:text-white/35 outline-none focus:border-yellow-300"
              />
              <div className="flex gap-4 flex-wrap justify-center">
                <button
                  onClick={() => setScreen('splash')}
                  className="px-8 py-4 rounded-2xl bg-white/10 text-white font-black border border-white/20"
                >
                  Back
                </button>
                <button
                  onClick={handleSaveProfileName}
                  className="px-10 py-4 rounded-2xl bg-gradient-to-b from-emerald-400 to-emerald-600 text-white font-black shadow-[0_8px_0_#059669] hover:shadow-[0_5px_0_#059669] active:shadow-none transition-all"
                >
                  Choose avatar
                </button>
              </div>
            </div>
          </div>
        );

      case 'avatar_selection':
        return (
          <AvatarSelect
            selectedId={player.avatarId}
            onSelect={id => setPlayer(prev => ({ ...prev, avatarId: id }))}
            onConfirm={handleAvatarConfirm}
          />
        );

      case 'world_map':
        return <WorldMap player={player} onSelectIsland={handleIslandSelect} />;

      case 'island_levels':
        return selectedIsland ? (
          <IslandLevels
            island={selectedIsland}
            player={player}
            onBack={goToHome}
            onSelectLevel={handleLevelSelect}
          />
        ) : null;

      case 'gameplay':
        return renderGameplay();

      case 'parent_dashboard':
        return <ParentDashboard player={player} onBack={goToHome} />;

      default:
        return <div className="text-white">Screen {screen} not implemented</div>;
    }
  };

  const showBottomNav = ['world_map', 'avatar_selection', 'parent_dashboard'].includes(screen);
  const isWideScreenScene = ['world_map', 'island_levels', 'gameplay', 'parent_dashboard'].includes(screen);

  return (
    <div className={`h-screen w-full flex flex-col items-center overflow-hidden ${isWideScreenScene ? 'bg-slate-900' : 'cloud-bg p-2 md:p-8'}`}>
      <AnimatePresence mode="wait">
        <motion.div
          key={screen}
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 1.02 }}
          className={`w-full flex-1 flex justify-center relative z-10 overflow-hidden ${isWideScreenScene ? '' : 'max-w-7xl mx-auto'}`}
        >
          {renderScreen()}
        </motion.div>
      </AnimatePresence>

      <DailyRewardsModal
        isOpen={showDailyRewards}
        onClose={() => setShowDailyRewards(false)}
        streak={player.dailyStreak}
        claimedToday={player.claimedDailyRewardToday}
        onClaim={handleClaimDailyReward}
      />

      <DailyQuestsModal
        isOpen={showQuests}
        onClose={() => setShowQuests(false)}
        quests={player.dailyQuests}
        onClaimQuest={handleClaimQuest}
      />

      <AchievementsModal
        isOpen={showAchievements}
        onClose={() => setShowAchievements(false)}
        player={player}
      />

      {!isWideScreenScene && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="cloud w-64 h-24 top-20" style={{ animationDuration: '25s' }} />
          <div className="cloud w-48 h-16 top-40" style={{ animationDuration: '40s', animationDelay: '-10s' }} />
          <div className="cloud w-80 h-32 bottom-20" style={{ animationDuration: '30s', animationDelay: '-5s' }} />
        </div>
      )}

      {showBottomNav && (
        <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white/20 backdrop-blur-xl px-5 md:px-8 py-3 md:py-4 rounded-full border-2 border-white/30 shadow-2xl flex gap-5 md:gap-8 z-50">
          <button
            onClick={goToHome}
            className={`p-2 rounded-2xl transition-all ${screen === 'world_map' ? 'bg-white text-blue-500 scale-110 shadow-lg' : 'text-white hover:bg-white/20'}`}
          >
            <Home />
          </button>
          <button
            onClick={() => setScreen('avatar_selection')}
            className={`p-2 rounded-2xl transition-all ${screen === 'avatar_selection' ? 'bg-white text-blue-500 scale-110 shadow-lg' : 'text-white hover:bg-white/20'}`}
          >
            <User />
          </button>
          <button
            onClick={() => setShowQuests(true)}
            className="p-2 rounded-2xl text-white hover:bg-white/20 transition-all relative"
          >
            <ClipboardList />
            {(player.dailyQuests || []).some(q => q.current >= q.target && !q.isClaimed) && (
              <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full border-2 border-white animate-pulse" />
            )}
          </button>
          <button
            onClick={() => setShowAchievements(true)}
            className="p-2 rounded-2xl text-white hover:bg-white/20 transition-all relative"
          >
            <Medal />
            {(player.achievements?.length || 0) > 0 && (
              <span className="absolute top-0 right-0 w-3 h-3 bg-yellow-400 rounded-full border-2 border-white" />
            )}
          </button>
          <button
            onClick={() => setScreen('parent_dashboard')}
            className={`p-2 rounded-2xl transition-all ${screen === 'parent_dashboard' ? 'bg-white text-blue-500 scale-110 shadow-lg' : 'text-white hover:bg-white/20'}`}
          >
            <Settings />
          </button>
        </nav>
      )}
    </div>
  );
};

export default App;
