import React from 'react';
import { motion } from 'motion/react';
import { Check, Sparkles } from './GameIcons';
import { AVATARS } from '../constants';

interface AvatarSelectProps {
  selectedId: string;
  onSelect: (id: string) => void;
  onConfirm: () => void;
}

const AvatarSelect: React.FC<AvatarSelectProps> = ({ selectedId, onSelect, onConfirm }) => {
  const selectedAvatar = AVATARS.find(avatar => avatar.id === selectedId) || AVATARS[0];

  return (
    <div className="relative my-auto flex w-full max-w-6xl flex-col items-center gap-8 px-4 py-6 md:gap-10 md:px-8">
      <div className="glass-panel absolute inset-x-4 top-1/2 -z-10 h-[88%] -translate-y-1/2 rounded-[2.8rem] md:inset-x-8" />
      <div className="absolute left-12 top-12 h-40 w-40 rounded-full bg-cyan-300/10 blur-3xl" />
      <div className="absolute bottom-12 right-12 h-48 w-48 rounded-full bg-fuchsia-400/10 blur-3xl" />

      <div className="relative z-10 text-center">
        <div className="mb-4 flex justify-center gap-2">
          {['Pick a companion', 'Animated map', 'Portrait UI'].map(label => (
            <span key={label} className="game-chip">{label}</span>
          ))}
        </div>
        <h1 className="text-4xl font-black tracking-tight text-white drop-shadow-[0_4px_0_rgba(0,0,0,0.18)] md:text-6xl">
          Choose Your Hero
        </h1>
        <p className="mt-2 text-[11px] font-bold uppercase tracking-[0.28em] text-white/65 md:text-sm">
          Select your companion for the journey
        </p>
      </div>

      <div className="glass-panel relative z-10 flex w-full max-w-2xl items-center gap-4 overflow-hidden rounded-[2rem] px-5 py-5 md:px-6">
        <div className={`relative flex h-24 w-24 items-center justify-center rounded-[1.8rem] border border-white/20 ${selectedAvatar.color} text-5xl shadow-xl md:h-28 md:w-28 md:text-6xl`}>
          <div className="shine" />
          {selectedAvatar.image}
        </div>
        <div className="min-w-0 flex-1 text-left text-white">
          <div className="flex items-center gap-2">
            <h2 className="truncate text-2xl font-black tracking-tight md:text-3xl">{selectedAvatar.name}</h2>
            <span className="rounded-full border border-yellow-300/40 bg-yellow-300/15 px-3 py-1 text-[10px] font-black uppercase tracking-[0.24em] text-yellow-100">
              {selectedAvatar.rarity}
            </span>
          </div>
          <p className="mt-2 max-w-lg text-sm font-bold text-white/70 md:text-base">
            A bright chaos-kawaii companion ready to carry your progress across every island.
          </p>
          <div className="mt-3 flex items-center gap-2 text-cyan-100">
            <Sparkles className="h-4 w-4" />
            <span className="text-xs font-black uppercase tracking-[0.25em]">Selected hero ready</span>
          </div>
        </div>
      </div>

      <div className="relative z-10 grid w-full grid-cols-2 gap-4 overflow-y-auto rounded-[2.25rem] border border-white/10 bg-black/10 p-3 backdrop-blur-xl sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 max-h-[46vh] md:max-h-none md:gap-5 md:p-4">
        {AVATARS.map((avatar) => {
          const isSelected = selectedId === avatar.id;
          return (
            <motion.button
              key={avatar.id}
              whileHover={{ scale: 1.04, y: -4 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => onSelect(avatar.id)}
              className={`relative overflow-hidden rounded-[2rem] border p-4 text-center transition-all md:p-5 ${
                isSelected
                  ? 'border-yellow-300 bg-white/22 shadow-[0_20px_40px_rgba(0,0,0,0.22)]'
                  : 'border-white/10 bg-white/8 hover:bg-white/14'
              }`}
            >
              <div className="shine" />
              <div className={`mx-auto flex h-20 w-20 items-center justify-center rounded-[1.4rem] border border-white/15 ${avatar.color} text-4xl shadow-lg md:h-24 md:w-24 md:text-5xl`}>
                {avatar.image}
              </div>
              <div className="mt-4 text-sm font-black tracking-tight text-white md:text-base">{avatar.name}</div>
              <div className="mt-1 text-[9px] font-black uppercase tracking-[0.24em] text-white/50 md:text-[10px]">
                {avatar.rarity}
              </div>

              {isSelected && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute right-3 top-3 rounded-xl border-2 border-white bg-gradient-to-b from-yellow-300 to-yellow-500 p-1.5 text-white shadow-xl"
                >
                  <Check className="h-4 w-4 stroke-[4px]" />
                </motion.div>
              )}
            </motion.button>
          );
        })}
      </div>

      <motion.button
        whileHover={{ scale: 1.03, y: -4 }}
        whileTap={{ scale: 0.97 }}
        onClick={onConfirm}
        className="game-button-primary relative z-10 rounded-[2rem] px-12 py-4 text-xl md:px-20 md:py-6 md:text-3xl"
      >
        Let&apos;s Go
      </motion.button>
    </div>
  );
};

export default AvatarSelect;
